﻿Public Class frmSysReport
    'Dim rptReport As CrystalDecisions.CrystalReports.Engine.ReportDocument

    Private Sub frmReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Me.crvViewer.RefreshReport()
    End Sub

    'Tambahan Report() utk set PaperSize dan Orientation Sesuai Inventory
    'Public Property Report() As CrystalDecisions.CrystalReports.Engine.ReportDocument
    '    Get
    '        Return rptReport
    '    End Get
    '    Set(ByVal Value As CrystalDecisions.CrystalReports.Engine.ReportDocument)
    '        rptReport = Value
    '    End Set
    'End Property


End Class