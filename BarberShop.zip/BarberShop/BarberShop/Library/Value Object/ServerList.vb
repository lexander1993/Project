﻿Namespace VO

    Public Class ServerList

        Public Shared ServerList As DataTable

    End Class

End Namespace
