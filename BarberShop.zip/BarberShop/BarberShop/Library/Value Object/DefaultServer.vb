﻿Namespace VO

    Public Class DefaultServer

        Public Shared Server, Database As String

    End Class

End Namespace
