Namespace UI

    Public Class usUserApp

        Public Shared AppVersion As String = "Version 1.0.0"
        Public Shared SuperAdminID As String = "ALEXANDER.YEN"
        Public Shared SuperAdminPassword As String = "Gant8*Paslo3"

        Public Shared FileLocation As String '= "\\TJM-ID-DT-9046\Sharedocs\NMS Data\File\"
        Public Shared ExportFileLocation As String '= "\\TJM-ID-DT-9046\Sharedocs\NMS Data\File\"
        Public Shared TemplateLocation As String
        Public Shared BlankTemplateLocation As String
        Public Shared ExportLocation As String
        Public Shared BackupLocation As String
        Public Shared Help As String

        Public Shared AdminID As String '= "ENDRA THASLIM"
        Public Shared AdminName As String '= "ENDRA THASLIM, Sarjana Hukum"
        Public Shared AdminAddress As String '= "Williem Iskandar (Jl. Pancing), Komplek MMTC Blok D No. 50"
        Public Shared AdminNPWP As String '= "09.850.462.4-121.000"
        Public Shared AdminDaerahKerja As String '= "Kabupaten Deli Serdang"
        Public Shared CompanyID As String '= "MITRA SUKSES"

        Public Shared CompanyName As String 'Barber Shop'
        Public Shared CompanyAddress As String 'DPangkas
        Public Shared PrintPayment As String 'DPangkas

        Public Shared UserID As String
        Public Shared LocationID, LocationName As String



    End Class

End Namespace
