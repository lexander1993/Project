Namespace UI

    Public Class usDefGrid

        Public Shared gString As Integer = 0
        Public Shared gSmallDate As Integer = 1
        Public Shared gFullDate As Integer = 2
        Public Shared gIntNum As Integer = 3
        Public Shared gBoolean As Integer = 4
        Public Shared gReal1Num As Integer = 5
        Public Shared gReal2Num As Integer = 6
        Public Shared gReal3Num As Integer = 7
        Public Shared gReal4Num As Integer = 8
        Public Shared gReal5Num As Integer = 9
        Public Shared gReal6Num As Integer = 10
    End Class

End Namespace

